const products = [
      {
        name: "Dino Friends",
        subtitle: "Tiny dinosaurs, big imagination.",
        image: "assets/set-1.jpg",
        tag: "Roar & Paint"
      },
      {
        name: "Little Vehicles",
        subtitle: "Cars, trucks & adventures to colour.",
        image: "assets/set-2.jpg",
        tag: "Vroom!"
      },
      {
        name: "Fruit & Food",
        subtitle: "A playful little world to paint.",
        image: "assets/set-3.jpg",
        tag: "Yum & Create"
      },
      {
        name: "Animal Friends",
        subtitle: "Cute characters made for little artists.",
        image: "assets/set-4.jpg",
        tag: "Paint & Play"
      },
      {
        name: "Adventure Set",
        subtitle: "Build a colourful story of your own.",
        image: "assets/set-5.jpg",
        tag: "Imagine More"
      },
      {
        name: "Mix & Match",
        subtitle: "A surprise collection for creative hands.",
        image: "assets/set-6.jpg",
        tag: "Create Your Way"
      }
];

const grid = document.getElementById("products");
products.forEach((p) => {
  const card = document.createElement("article");
  card.className = "product";
  card.innerHTML = `
    <div class="product-image"><img src="${p.image}" alt="${p.name} clay toy set" loading="lazy"></div>
    <div class="product-info">
      <div class="tag">${p.tag}</div>
      <h3>${p.name}</h3>
      <p>${p.subtitle}</p>
      <button type="button" onclick="contactKit('${p.name}')">I'm interested →</button>
    </div>`;
  grid.appendChild(card);
});

function contactKit(name) {
  const subject = encodeURIComponent("Little Art Co. — " + name);
  window.location.href = "mailto:hello@littleartco.example?subject=" + subject;
}

document.getElementById("year").textContent = new Date().getFullYear();
