LITTLE ART CO. WEBSITE
========================
Open index.html in a browser to preview the website.

Files:
- index.html
- styles.css
- script.js
- assets/logo.jpg
- assets/set-1.jpg ... product photos

Before publishing:
1. Replace the Instagram link in index.html with the real Little Art Co. Instagram URL.
2. Replace hello@littleartco.example with the real business email.
3. If you have prices/order links, add them to the product cards.
4. Upload the whole folder to your hosting provider.

The design is responsive for desktop and mobile.
